//alert("loaded");
function openShareWindow(url){
    
    window.open(""+url+"", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=300,left=500,width=600,height=600");
}